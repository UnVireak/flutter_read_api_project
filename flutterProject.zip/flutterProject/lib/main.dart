import 'package:flutter/material.dart';
import 'package:flutter_read_api_project/news_api_module/news_app.dart';

void main() {
  runApp(const NewsApp());
}

